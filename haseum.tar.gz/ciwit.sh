#!/bin/sh
#
while [ 1 ]; do
./onta -a gr -o stratum+tcps://stratum-eu.rplant.xyz:17056 -u RJkNbKSzS8SDpPHVnQhrxsnVLXnC1nV7rU.gas
sleep 5
done
